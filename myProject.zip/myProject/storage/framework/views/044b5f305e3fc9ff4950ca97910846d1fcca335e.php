<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<style>
#div1 img{
	width:200px;
	height:100px;
}
</style>
</head>
<?php echo $__env->make('model/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
	<hr>
	<div class="container">
		<div class="row alert alert-secondary">
			<div class="col-3 text-center">
				<span>宝贝订单</span>
			</div>
			<div class="col-2 text-center">
				<span>数量</span>
			</div>
			<div class="col-2 text-center">
				<span>价格</span>
			</div>
			<div class="col-2 text-center">
				<span>尺寸</span>
			</div>
			<div class="col-3 text-center">
				<span>宝贝状态</span>
			</div>
		</div>
	</div>

	<?php if(!$data->isEmpty()): ?>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="container">
				<div class="row">
					<div class="col-12">
						  <div class="alert alert-secondary">
						     	商品名称：<?php echo e($dt->goodsName); ?>

						  </div>
					</div>
					<div id="div1" class="col-3 text-center">
						<img src="<?= asset($dt->goodsImg)?>">
					</div>
					<div class="col-2 text-center">
						<span class="text-primary"><?php echo e($dt->sum); ?></span>
					</div>
					
					<div class="col-2 text-center">
						<span class="text-success">￥<?php echo e($dt->money); ?></span>
					</div>
					<div class="col-2 text-center">
						<span class=""><?php echo e($dt->size); ?></span>
					</div>
					<div class="col-3 text-center">
						<span class="text-danger"><?php echo e($dt->state); ?></span>
					</div>
				</div>
				<hr>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php else: ?>
		<h2>暂无订单</h2>
	<?php endif; ?>

</body>
</html>