<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<style>
#div1 img{
	width:200px;
	height:100px;
}
</style>
</head>
<?php echo $__env->make('model/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
	<hr>
	<div class="container">
		<div class="row alert alert-secondary">
			<div class="col-3 text-center">
				<span>宝贝</span>
			</div>
			<div class="col-2 text-center">
				<span>数量</span>
			</div>
			<div class="col-2 text-center">
				<span>价格</span>
			</div>
			<div class="col-2 text-center">
				<span>尺寸</span>
			</div>
			<div class="col-3 text-center">
				<span>宝贝状态</span>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-12">
				  <div class="alert alert-secondary">
				     	商品名称
				  </div>
			</div>
			<div id="div1" class="col-3 text-center">
				<img src="<?= asset('img/test1.jpg')?>">
			</div>
			<div class="col-2 text-center">
				<span class="text-primary">234</span>
			</div>
			
			<div class="col-2 text-center">
				<span class="text-success">￥888.8</span>
			</div>
			<div class="col-2 text-center">
				<span class="">L</span>
			</div>
			<div class="col-3 text-center">
				<span class="text-danger">已付款</span>
			</div>
		</div>
		<hr>
	</div>

</body>
</html>